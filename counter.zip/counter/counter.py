from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'x'
@app.route('/')
def index():
    if 'count' not in session:
        session['count'] = 0
    session['count'] += 1
    return render_template('index.html')
@app.route('/process', methods=['POST'])
def process():
    two = request.form['two']
    reset = request.form['reset']
    if 'reset' in session:
        session['count'] = 0
    if 'two' in session:
        session['count'] += 2
    return render_template('index.html', reset=reset, two=two)
app.run(debug=True)
